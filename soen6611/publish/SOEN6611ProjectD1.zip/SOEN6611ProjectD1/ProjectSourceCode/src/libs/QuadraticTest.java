package libs;

import static org.junit.Assert.*;

import org.junit.Test;

public class QuadraticTest {

	@Test
	public void testSolve() {
		fail("Not yet implemented");
	}

}
