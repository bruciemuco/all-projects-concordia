/*
 * SOEN6611 Project
 * 
 * UI interface to show messages on screen
 * 
 * This file is created by Team F
 * Licensed under GNU GPL v3
 * 
 * $Author: ewan.msn@gmail.com $
 * $Date: 2012-07-13 21:59:51 -0400 (Fri, 13 Jul 2012) $
 * $Rev: 112 $
 * $HeadURL: https://all-projects-concordia.googlecode.com/svn/soen6611/MinskPrjD1/src/ui/UIBasicInf.java $
 * 
 */

package ui;

public interface UIBasicInf {
	public void showGreetings();
	public void showCommands();
	public int getCommand();
	public int getPrimeInputs();
	public double getQuaInputs(int constant);
	public void showResults(Object arg);
}
